const {
  Client,
  GatewayIntentBits,
  Partials,
  PermissionsBitField,
  ChannelType,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  SlashCommandBuilder,
  REST,
  Routes,
  Events
} = require("discord.js");
const express = require("express");

const {
  BOT_TOKEN,
  CLIENT_ID,
  GUILD_ID,
  CATEGORY_ID,
  LOG_CHANNEL_ID,
  PANEL_CHANNEL_ID,
  STAFF_ROLE_ID,
  PORT
} = process.env;

const REQUIRED_VARS = [
  "BOT_TOKEN",
  "CLIENT_ID",
  "GUILD_ID",
  "CATEGORY_ID",
  "LOG_CHANNEL_ID",
  "PANEL_CHANNEL_ID",
  "STAFF_ROLE_ID"
];

for (const key of REQUIRED_VARS) {
  if (!process.env[key]) {
    console.error(`Missing required environment variable: ${key}`);
    process.exit(1);
  }
}

const BRAND = {
  color: 0xD71920,
  name: "Austrian Airlines Guest Care",
  footer: "Austrian Airlines • Premium Guest Support",
  emoji: "✈️"
};

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel]
});

const app = express();
app.get("/", (_, res) => {
  res.send("Austrian Airlines Modmail bot is running.");
});
app.listen(PORT || 3000, () => {
  console.log(`Health server listening on port ${PORT || 3000}`);
});

function buildEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(BRAND.color)
    .setTitle(`${BRAND.emoji} ${title}`)
    .setDescription(description)
    .setFooter({ text: BRAND.footer })
    .setTimestamp();
}

function sanitizeChannelName(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80);
}

function getTicketTopic(userId) {
  return `modmail_user:${userId}`;
}

function extractUserIdFromTopic(topic) {
  if (!topic) return null;
  const match = topic.match(/modmail_user:(\d{17,20})/);
  return match ? match[1] : null;
}

async function registerCommands() {
  const commands = [
    new SlashCommandBuilder()
      .setName("setup")
      .setDescription("Posts the Austrian Airlines modmail panel.")
      .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator),

    new SlashCommandBuilder()
      .setName("reply")
      .setDescription("Reply to the passenger tied to this modmail channel.")
      .addStringOption(option =>
        option
          .setName("message")
          .setDescription("Message to send to the passenger")
          .setRequired(true)
      )
      .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageMessages),

    new SlashCommandBuilder()
      .setName("close")
      .setDescription("Closes the current modmail ticket.")
      .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageChannels),

    new SlashCommandBuilder()
      .setName("rename")
      .setDescription("Rename the current ticket channel.")
      .addStringOption(option =>
        option
          .setName("name")
          .setDescription("New ticket label, for example delayed-baggage")
          .setRequired(true)
      )
      .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageChannels)
  ].map(command => command.toJSON());

  const rest = new REST({ version: "10" }).setToken(BOT_TOKEN);
  await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), {
    body: commands
  });
  console.log("Slash commands registered.");
}

async function findExistingTicketChannel(guild, userId) {
  const channels = await guild.channels.fetch();
  return (
    channels.find(
      channel =>
        channel &&
        channel.parentId === CATEGORY_ID &&
        channel.topic === getTicketTopic(userId)
    ) || null
  );
}

async function createTicketChannel(guild, user) {
  const baseName = sanitizeChannelName(`passenger-${user.username}`);

  const channel = await guild.channels.create({
    name: baseName || `passenger-${user.id}`,
    type: ChannelType.GuildText,
    parent: CATEGORY_ID,
    topic: getTicketTopic(user.id),
    permissionOverwrites: [
      {
        id: guild.roles.everyone.id,
        deny: [PermissionsBitField.Flags.ViewChannel]
      },
      {
        id: STAFF_ROLE_ID,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
          PermissionsBitField.Flags.AttachFiles,
          PermissionsBitField.Flags.EmbedLinks,
          PermissionsBitField.Flags.ManageChannels
        ]
      },
      {
        id: client.user.id,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
          PermissionsBitField.Flags.ManageChannels,
          PermissionsBitField.Flags.EmbedLinks,
          PermissionsBitField.Flags.AttachFiles
        ]
      }
    ]
  });

  const intro = buildEmbed(
    "New Passenger Case Opened",
    `A new guest support conversation has been created for <@${user.id}>.\n\n**Passenger:** ${user.tag}\n**User ID:** ${user.id}\n\nUse **/reply** to answer and **/close** when finished.`
  );

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("close_ticket")
      .setLabel("Close Ticket")
      .setStyle(ButtonStyle.Danger)
      .setEmoji("🔒")
  );

  await channel.send({
    content: `<@&${STAFF_ROLE_ID}>`,
    embeds: [intro],
    components: [row]
  });

  return channel;
}

async function sendLog(guild, embed) {
  const logChannel = await guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
  if (logChannel && logChannel.isTextBased()) {
    await logChannel.send({ embeds: [embed] }).catch(() => null);
  }
}

async function ensureTicketForUser(user) {
  const guild = await client.guilds.fetch(GUILD_ID);
  await guild.channels.fetch();

  let channel = await findExistingTicketChannel(guild, user.id);
  if (!channel) {
    channel = await createTicketChannel(guild, user);
  }

  return { guild, channel };
}

client.once(Events.ClientReady, async readyClient => {
  console.log(`Logged in as ${readyClient.user.tag}`);
  try {
    await registerCommands();
  } catch (error) {
    console.error("Failed to register commands:", error);
  }
});

client.on(Events.InteractionCreate, async interaction => {
  if (interaction.isButton()) {
    if (interaction.customId === "open_modmail") {
      await interaction.reply({
        content: "Please send me a DM with your support request and our team will assist you shortly.",
        ephemeral: true
      });
      return;
    }

    if (interaction.customId === "close_ticket") {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageChannels)) {
        await interaction.reply({ content: "You do not have permission to close tickets.", ephemeral: true });
        return;
      }

      const userId = extractUserIdFromTopic(interaction.channel.topic);
      if (!userId) {
        await interaction.reply({ content: "This channel is not linked to a passenger.", ephemeral: true });
        return;
      }

      const user = await client.users.fetch(userId).catch(() => null);
      if (user) {
        await user.send({
          embeds: [
            buildEmbed(
              "Case Closed",
              "Your Austrian Airlines support conversation has now been closed. If you need anything else, you can send me another DM at any time."
            )
          ]
        }).catch(() => null);
      }

      await sendLog(
        interaction.guild,
        buildEmbed(
          "Case Closed",
          `Ticket **#${interaction.channel.name}** was closed by <@${interaction.user.id}>.`
        )
      );

      await interaction.reply({ content: "Closing ticket in 5 seconds...", ephemeral: false });
      setTimeout(() => {
        interaction.channel.delete().catch(() => null);
      }, 5000);
      return;
    }
  }

  if (!interaction.isChatInputCommand()) return;

  if (interaction.commandName === "setup") {
    const panelChannel = await interaction.guild.channels.fetch(PANEL_CHANNEL_ID).catch(() => null);
    if (!panelChannel || !panelChannel.isTextBased()) {
      await interaction.reply({
        content: "PANEL_CHANNEL_ID is invalid or not a text channel.",
        ephemeral: true
      });
      return;
    }

    const embed = buildEmbed(
      "Austrian Airlines Guest Care",
      "Need help with a booking, baggage issue, seat request, refund question, or another support matter?\n\nPress the button below, then send the bot a **DM** to open a private guest care case."
    );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("open_modmail")
        .setLabel("Open Guest Care")
        .setStyle(ButtonStyle.Danger)
        .setEmoji("✈️")
    );

    await panelChannel.send({ embeds: [embed], components: [row] });
    await interaction.reply({ content: `Panel posted in <#${PANEL_CHANNEL_ID}>.`, ephemeral: true });
    return;
  }

  if (interaction.commandName === "reply") {
    const userId = extractUserIdFromTopic(interaction.channel.topic);
    if (!userId) {
      await interaction.reply({ content: "This is not a modmail ticket channel.", ephemeral: true });
      return;
    }

    const message = interaction.options.getString("message", true);
    const user = await client.users.fetch(userId).catch(() => null);

    if (!user) {
      await interaction.reply({ content: "Could not find the linked passenger.", ephemeral: true });
      return;
    }

    await user.send({
      embeds: [
        buildEmbed(
          "Message from Guest Care",
          `${message}\n\n_Answered by ${interaction.user.tag}_`
        )
      ]
    });

    await interaction.channel.send({
      embeds: [
        buildEmbed(
          "Reply Sent",
          `**To:** <@${user.id}>\n**From:** <@${interaction.user.id}>\n\n${message}`
        )
      ]
    });

    await interaction.reply({ content: "Reply sent.", ephemeral: true });
    return;
  }

  if (interaction.commandName === "close") {
    const userId = extractUserIdFromTopic(interaction.channel.topic);
    if (!userId) {
      await interaction.reply({ content: "This is not a modmail ticket channel.", ephemeral: true });
      return;
    }

    const user = await client.users.fetch(userId).catch(() => null);
    if (user) {
      await user.send({
        embeds: [
          buildEmbed(
            "Case Closed",
            "Your Austrian Airlines support conversation has now been closed. If you need anything else, you can send me another DM at any time."
          )
        ]
      }).catch(() => null);
    }

    await sendLog(
      interaction.guild,
      buildEmbed(
        "Case Closed",
        `Ticket **#${interaction.channel.name}** was closed by <@${interaction.user.id}>.`
      )
    );

    await interaction.reply({ content: "Closing ticket in 5 seconds..." });
    setTimeout(() => {
      interaction.channel.delete().catch(() => null);
    }, 5000);
    return;
  }

  if (interaction.commandName === "rename") {
    const userId = extractUserIdFromTopic(interaction.channel.topic);
    if (!userId) {
      await interaction.reply({ content: "This is not a modmail ticket channel.", ephemeral: true });
      return;
    }

    const newName = sanitizeChannelName(interaction.options.getString("name", true));
    await interaction.channel.setName(newName);
    await interaction.reply({ content: `Ticket renamed to **${newName}**.` });
    return;
  }
});

client.on(Events.MessageCreate, async message => {
  if (message.author.bot) return;

  if (message.guild) {
    const userId = extractUserIdFromTopic(message.channel.topic);
    if (!userId) return;

    if (!message.member.roles.cache.has(STAFF_ROLE_ID)) return;
    if (message.content.startsWith("/")) return;

    const user = await client.users.fetch(userId).catch(() => null);
    if (!user) return;

    await user.send({
      embeds: [
        buildEmbed(
          "Message from Guest Care",
          `${message.content}\n\n_Answered by ${message.author.tag}_`
        )
      ]
    }).catch(() => null);

    await message.react("✅").catch(() => null);
    return;
  }

  const dmMessage = message;
  const user = dmMessage.author;

  const { guild, channel } = await ensureTicketForUser(user);

  const attachmentLines = [...dmMessage.attachments.values()].map(file => `• ${file.url}`);
  const attachmentText = attachmentLines.length
    ? `\n\n**Attachments**\n${attachmentLines.join("\n")}`
    : "";

  await channel.send({
    embeds: [
      buildEmbed(
        "Passenger Message Received",
        `**From:** <@${user.id}> (${user.tag})\n\n${dmMessage.content || "[No text content]"}${attachmentText}`
      )
    ]
  });

  await sendLog(
    guild,
    buildEmbed(
      "Passenger Update",
      `<@${user.id}> sent a new message in ticket **#${channel.name}**.`
    )
  );

  await dmMessage.channel.send({
    embeds: [
      buildEmbed(
        "Request Received",
        "Thank you for contacting Austrian Airlines Guest Care. A member of our team will respond here as soon as possible."
      )
    ]
  }).catch(() => null);
});

client.login(BOT_TOKEN);
